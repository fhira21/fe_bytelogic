const CLIENT_ROLE = 'client'
const EMPLOYEE_ROLE = 'karyawan'
const ADMIN_ROLE = 'manager/admin'

module.exports = {
    CLIENT_ROLE,
    EMPLOYEE_ROLE,
    ADMIN_ROLE
}