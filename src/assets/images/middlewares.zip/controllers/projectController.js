const { ADMIN_ROLE, CLIENT_ROLE, EMPLOYEE_ROLE } = require("../constants/role");
const Project = require("../models/Project");
const { createRepository, updateRepository, getCommits } = require("../services/githubService");

exports.createProject = async (req, res) => {
  try {
    const { title, description, client_id, employees, deadline, github_token, status } = req.body;

    const gitHubCreateResponse = await createRepository(github_token, title, description)

    const imagePaths = req.files.map(file => "/uploads/" + file.filename);

    const project = await Project.create({
      title,
      description,
      status,
      deadline,
      client: client_id,
      manager: req.user.id,
      employees,

      images: imagePaths,

      github_repo_name: gitHubCreateResponse.name,
      github_repo_url: `https://github.com/${gitHubCreateResponse.full_name}`,
      github_username: gitHubCreateResponse.owner.login,
      github_fine_grain_token: github_token,
      sdlc_progress: {
        analisis: 0,
        desain: 0,
        implementasi: 0,
        pengujian: 0,
        maintenance: 0,
      }
    });

    res.status(201).json({ message: "Proyek berhasil dibuat", project });
  } catch (error) {
    res.status(500).json({ message: "Gagal membuat proyek", error });
  }
};

exports.getProjects = async (req, res) => {
  try {
    let projects;
    if (req.user.role === ADMIN_ROLE) {
      projects = await Project.find({}, '-github_commits').populate("client", "name").populate("employees", "name");
    } else if (req.user.role === CLIENT_ROLE) {
      projects = await Project.find({ client: req.user.userId }, '-github_commits').populate("employees", "name");
    } else if (req.user.role === EMPLOYEE_ROLE) {
      projects = await Project.find({ employees: req.user.userId }, '-github_commits').populate("client", "name");
    } else {
      return res.status(403).json({ message: "Akses tidak diizinkan" });
    }

    res.status(200).json({ message: "Berhasil mengambil proyek", data: projects });
  } catch (error) {
    res.status(500).json({ message: "Gagal mengambil data proyek", error });
  }
};

exports.getProjectById = async (req, res) => {
  try {
    const { projectId } = req.params;

    const project = await Project.findById(projectId).select('+github_fine_grain_token')

    if (project.github_fine_grain_token) {
      try {
        const commits = await getCommits(project.github_fine_grain_token, project.github_username, project.github_repo_name)

        const projectCommits = commits.map(item => ({
          message: item.commit.message,
          author: item.commit.author.name,
          date: item.commit.author.date,
          url: item.html_url
        }))

        project.github_commits = projectCommits

        await project.save()
      } catch (error) {

      }
    }

    return res.status(200).json({ message: "Data proyek berhasil diambil", data: project });
  } catch (error) {
    return res.status(500).json({ message: "Gagal mengambil proyek", error: error.message, errorstack: error });
  }
}

exports.updateProject = async (req, res) => {
  try {
    const { projectId } = req.params;

    if (req.user.role === ADMIN_ROLE) {
      const {
        title,
        description,
        client_id,
        employees,
        deadline,
        github_token,
        status,
        sdlc_progress,
        image_to_delete // ← bisa dalam bentuk array atau string
      } = req.body;

      const project = await Project.findOne({ _id: projectId });
      if (!project) {
        return res.status(404).json({ message: "Proyek tidak ditemukan" });
      }

      try {
        const commits = await getCommits(
          project.github_fine_grain_token,
          project.github_username,
          project.github_repo_name
        );
  
        const projectCommits = commits.map(item => ({
          message: item.commit.message,
          author: item.commit.author.name,
          date: item.commit.author.date,
          url: item.html_url
        }));
  
        project.github_commits = projectCommits;
      } catch (error) {
        
      }

      // Handle update GitHub repo jika ada perubahan title/description
      let updateRepositoryResponse = null;
      if ((title || description) && (title !== "" || description !== "")) {
        updateRepositoryResponse = await updateRepository(
          github_token,
          project.github_username,
          project.github_repo_name,
          title || project.title,
          description || project.description
        );
      }

      // ==== Handle Gambar ====
      // 1. Hapus image berdasarkan index
      if (image_to_delete) {
        let deleteIndexes = Array.isArray(image_to_delete)
          ? image_to_delete.map(i => parseInt(i))
          : [parseInt(image_to_delete)];

        // Sort descending biar index nggak bergeser pas splice
        deleteIndexes.sort((a, b) => b - a);

        for (let index of deleteIndexes) {
          if (project.images && index >= 0 && index < project.images.length) {
            project.images.splice(index, 1);
          }
        }
      }

      // 2. Tambahkan image baru jika ada upload
      if (req.files && req.files.length > 0) {
        const uploadedPaths = req.files.map(file => "/uploads/" + file.filename);
        project.images.push(...uploadedPaths);
      }

      // ==== Update data lainnya ====
      project.title = title || project.title;
      project.description = description || project.description;
      project.client = client_id || project.client;
      project.employees = employees || project.employees;
      project.deadline = deadline || project.deadline;
      project.status = status || project.status;
      project.sdlc_progress = sdlc_progress
        ? JSON.parse(sdlc_progress)
        : project.sdlc_progress;
      project.github_fine_grain_token = github_token || project.github_fine_grain_token;

      if (updateRepositoryResponse) {
        project.github_repo_name = updateRepositoryResponse.name;
        project.github_repo_url = `https://github.com/${updateRepositoryResponse.full_name}`;
      }

      const updatedProject = await project.save();

      return res.status(200).json({ message: "Proyek berhasil diperbarui", updatedProject });
    }

  } catch (error) {
    return res.status(500).json({ message: "Gagal memperbarui proyek", error: error.message, errorstack: error });
  }
};


exports.deleteProject = async (req, res) => {
  if (req.user.role !== "manager") {
    return res.status(403).json({ message: "Hanya Manager yang dapat menghapus proyek." });
  }

  try {
    const { projectId } = req.params;
    const deletedProject = await Project.findByIdAndDelete(projectId);

    if (!deletedProject) {
      return res.status(404).json({ message: "Proyek tidak ditemukan" });
    }

    res.status(200).json({ message: "Proyek berhasil dihapus" });
  } catch (error) {
    res.status(500).json({ message: "Gagal menghapus proyek", error });
  }
};

exports.updateProgress = async (req, res) => {
  try {
    const { projectId } = req.params;
    const {
      analisis,
      desain,
      implementasi,
      pengujian,
      maintenance
    } = req.body;

    const project = await Project.findById(projectId).select('+github_fine_grain_token');
    if (!project) {
      return res.status(404).json({ message: "Proyek tidak ditemukan" });
    }

    if (!project.employees.includes(req.user.userId) && !project.manager == req.user.id) {
      return res.status(403).json({ message: "Anda tidak memiliki akses ke proyek ini." });
    }

    const commits = await getCommits(project.github_fine_grain_token, project.github_username, project.github_repo_name)

    const projectCommits = commits.map(item => ({
      message: item.commit.message,
      author: item.commit.author.name,
      date: item.commit.author.date,
      url: item.html_url
    }))

    project.github_commits = projectCommits

    project.sdlc_progress = {
      analisis,
      desain,
      implementasi,
      pengujian,
      maintenance
    };
    await project.save();

    res.status(200).json({ message: "Status proyek diperbarui", project });
  } catch (error) {
    res.status(500).json({ message: "Gagal memperbarui status proyek", error });
  }
};
